<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/_debugbar/open' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.openhandler',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/assets/stylesheets' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.assets.css',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_debugbar/assets/javascript' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.assets.js',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/filament/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.auth.logout',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.auth.login',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.pages.dashboard',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/company-external-apis' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.company-external-apis.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/company-external-apis/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.company-external-apis.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/company-offices' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.company-offices.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/company-offices/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.company-offices.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/companies' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.companies.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/companies/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.companies.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/contacts' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.contacts.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/contacts/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.contacts.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/customer-requests' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.customer-requests.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/customer-requests/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.customer-requests.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/external-apis' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.external-apis.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/external-apis/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.external-apis.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/real-estates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.real-estates.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/real-estates/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.real-estates.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/tasklists' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.tasklists.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/tasklists/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.tasklists.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.users.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/users/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.users.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/user-roles' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.user-roles.index',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/user-roles/create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.user-roles.create',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::T3fReigw31kMsa7l',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/upload-file' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.upload-file',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aBKdxSGBA9JBlZaa',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/livewire/livewire.js.map' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GkK0S8IINUs5Q8yX',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/filament-impersonate/leave' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament-impersonate.leave',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::awPjDdoy7AnysRXS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oGJyWVyIUcKZvoEG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/test/immo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'test.test.immo',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/app/test/wireui' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'test.test.',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/_debugbar/c(?|lockwork/([^/]++)(*:39)|ache/([^/]++)(?:/([^/]++))?(*:73))|/filament/assets/(.*)(*:102)|/app/(?|c(?|o(?|mpan(?|y\\-(?|external\\-apis/([^/]++)/edit(*:167)|offices/([^/]++)/edit(*:196))|ies/([^/]++)/edit(*:222))|ntacts/([^/]++)/edit(*:251))|ustomer\\-requests/([^/]++)/edit(*:291))|external\\-apis/([^/]++)/edit(*:328)|real\\-estates/([^/]++)/edit(*:363)|tasklists/([^/]++)/edit(*:394)|user(?|s/([^/]++)/edit(*:424)|\\-roles/([^/]++)/edit(*:453)))|/livewire/(?|message/([^/]++)(*:492)|preview\\-file/([^/]++)(*:522))|/immo/([^/]++)/([^/]++)(*:554))/?$}sDu',
    ),
    3 => 
    array (
      39 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.clockwork',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      73 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'debugbar.cache.delete',
            'tags' => NULL,
          ),
          1 => 
          array (
            0 => 'key',
            1 => 'tags',
          ),
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      102 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.asset',
          ),
          1 => 
          array (
            0 => 'file',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      167 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.company-external-apis.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      196 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.company-offices.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      222 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.companies.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      251 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.contacts.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      291 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.customer-requests.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      328 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.external-apis.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      363 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.real-estates.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      394 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.tasklists.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      424 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.users.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      453 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'filament.resources.user-roles.edit',
          ),
          1 => 
          array (
            0 => 'record',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      492 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.message',
          ),
          1 => 
          array (
            0 => 'name',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      522 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'livewire.preview-file',
          ),
          1 => 
          array (
            0 => 'filename',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      554 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rjqSMm7MoNuRSelQ',
          ),
          1 => 
          array (
            0 => 'realEstate',
            1 => 'slug',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'debugbar.openhandler' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/open',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@handle',
        'as' => 'debugbar.openhandler',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@handle',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.clockwork' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/clockwork/{id}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@clockwork',
        'as' => 'debugbar.clockwork',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\OpenHandlerController@clockwork',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.assets.css' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/assets/stylesheets',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@css',
        'as' => 'debugbar.assets.css',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@css',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.assets.js' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_debugbar/assets/javascript',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@js',
        'as' => 'debugbar.assets.js',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\AssetController@js',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'debugbar.cache.delete' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => '_debugbar/cache/{key}/{tags?}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Barryvdh\\Debugbar\\Middleware\\DebugbarEnabled',
        ),
        'uses' => 'Barryvdh\\Debugbar\\Controllers\\CacheController@delete',
        'as' => 'debugbar.cache.delete',
        'controller' => 'Barryvdh\\Debugbar\\Controllers\\CacheController@delete',
        'namespace' => 'Barryvdh\\Debugbar\\Controllers',
        'prefix' => '_debugbar',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.asset' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'filament/assets/{file}',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
        ),
        'uses' => 'Filament\\Http\\Controllers\\AssetController@__invoke',
        'controller' => 'Filament\\Http\\Controllers\\AssetController',
        'as' => 'filament.asset',
        'namespace' => NULL,
        'prefix' => '/filament',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
        'file' => '.*',
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.auth.logout' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'filament/logout',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:544:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:328:"function (): \\Filament\\Http\\Responses\\Auth\\Contracts\\LogoutResponse {
                \\Filament\\Facades\\Filament::auth()->logout();

                \\session()->invalidate();
                \\session()->regenerateToken();

                return \\app(\\Filament\\Http\\Responses\\Auth\\Contracts\\LogoutResponse::class);
            }";s:5:"scope";s:34:"Illuminate\\Support\\ServiceProvider";s:4:"this";N;s:4:"self";s:32:"00000000000006de0000000000000000";}";s:4:"hash";s:44:"D1Gvl+qW96htr5BfiEc9OIKsCIoZW9taNL2Q9KNWwGk=";}}',
        'as' => 'filament.auth.logout',
        'namespace' => NULL,
        'prefix' => '/filament',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.auth.login' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/login',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
        ),
        'uses' => 'Filament\\Http\\Livewire\\Auth\\Login@__invoke',
        'controller' => 'Filament\\Http\\Livewire\\Auth\\Login',
        'as' => 'filament.auth.login',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.pages.dashboard' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'Filament\\Pages\\Dashboard@__invoke',
        'controller' => 'Filament\\Pages\\Dashboard',
        'as' => 'filament.pages.dashboard',
        'namespace' => NULL,
        'prefix' => '/app',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.company-external-apis.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/company-external-apis',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyExternalApiResource\\Pages\\ListCompanyExternalApis@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyExternalApiResource\\Pages\\ListCompanyExternalApis',
        'as' => 'filament.resources.company-external-apis.index',
        'namespace' => NULL,
        'prefix' => 'app/company-external-apis',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.company-external-apis.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/company-external-apis/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyExternalApiResource\\Pages\\CreateCompanyExternalApi@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyExternalApiResource\\Pages\\CreateCompanyExternalApi',
        'as' => 'filament.resources.company-external-apis.create',
        'namespace' => NULL,
        'prefix' => 'app/company-external-apis',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.company-external-apis.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/company-external-apis/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyExternalApiResource\\Pages\\EditCompanyExternalApi@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyExternalApiResource\\Pages\\EditCompanyExternalApi',
        'as' => 'filament.resources.company-external-apis.edit',
        'namespace' => NULL,
        'prefix' => 'app/company-external-apis',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.company-offices.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/company-offices',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyOfficeResource\\Pages\\ListCompanyOffices@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyOfficeResource\\Pages\\ListCompanyOffices',
        'as' => 'filament.resources.company-offices.index',
        'namespace' => NULL,
        'prefix' => 'app/company-offices',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.company-offices.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/company-offices/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyOfficeResource\\Pages\\CreateCompanyOffice@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyOfficeResource\\Pages\\CreateCompanyOffice',
        'as' => 'filament.resources.company-offices.create',
        'namespace' => NULL,
        'prefix' => 'app/company-offices',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.company-offices.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/company-offices/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyOfficeResource\\Pages\\EditCompanyOffice@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyOfficeResource\\Pages\\EditCompanyOffice',
        'as' => 'filament.resources.company-offices.edit',
        'namespace' => NULL,
        'prefix' => 'app/company-offices',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.companies.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/companies',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\ListCompanies@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\ListCompanies',
        'as' => 'filament.resources.companies.index',
        'namespace' => NULL,
        'prefix' => 'app/companies',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.companies.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/companies/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\CreateCompany@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\CreateCompany',
        'as' => 'filament.resources.companies.create',
        'namespace' => NULL,
        'prefix' => 'app/companies',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.companies.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/companies/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\EditCompany@__invoke',
        'controller' => 'App\\Filament\\Resources\\CompanyResource\\Pages\\EditCompany',
        'as' => 'filament.resources.companies.edit',
        'namespace' => NULL,
        'prefix' => 'app/companies',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.contacts.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/contacts',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\ContactResource\\Pages\\ListContacts@__invoke',
        'controller' => 'App\\Filament\\Resources\\ContactResource\\Pages\\ListContacts',
        'as' => 'filament.resources.contacts.index',
        'namespace' => NULL,
        'prefix' => 'app/contacts',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.contacts.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/contacts/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\ContactResource\\Pages\\CreateContact@__invoke',
        'controller' => 'App\\Filament\\Resources\\ContactResource\\Pages\\CreateContact',
        'as' => 'filament.resources.contacts.create',
        'namespace' => NULL,
        'prefix' => 'app/contacts',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.contacts.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/contacts/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\ContactResource\\Pages\\EditContact@__invoke',
        'controller' => 'App\\Filament\\Resources\\ContactResource\\Pages\\EditContact',
        'as' => 'filament.resources.contacts.edit',
        'namespace' => NULL,
        'prefix' => 'app/contacts',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.customer-requests.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/customer-requests',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CustomerRequestResource\\Pages\\ListCustomerRequests@__invoke',
        'controller' => 'App\\Filament\\Resources\\CustomerRequestResource\\Pages\\ListCustomerRequests',
        'as' => 'filament.resources.customer-requests.index',
        'namespace' => NULL,
        'prefix' => 'app/customer-requests',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.customer-requests.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/customer-requests/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CustomerRequestResource\\Pages\\CreateCustomerRequest@__invoke',
        'controller' => 'App\\Filament\\Resources\\CustomerRequestResource\\Pages\\CreateCustomerRequest',
        'as' => 'filament.resources.customer-requests.create',
        'namespace' => NULL,
        'prefix' => 'app/customer-requests',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.customer-requests.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/customer-requests/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\CustomerRequestResource\\Pages\\EditCustomerRequest@__invoke',
        'controller' => 'App\\Filament\\Resources\\CustomerRequestResource\\Pages\\EditCustomerRequest',
        'as' => 'filament.resources.customer-requests.edit',
        'namespace' => NULL,
        'prefix' => 'app/customer-requests',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.external-apis.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/external-apis',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\ExternalApiResource\\Pages\\ListExternalApis@__invoke',
        'controller' => 'App\\Filament\\Resources\\ExternalApiResource\\Pages\\ListExternalApis',
        'as' => 'filament.resources.external-apis.index',
        'namespace' => NULL,
        'prefix' => 'app/external-apis',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.external-apis.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/external-apis/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\ExternalApiResource\\Pages\\CreateExternalApi@__invoke',
        'controller' => 'App\\Filament\\Resources\\ExternalApiResource\\Pages\\CreateExternalApi',
        'as' => 'filament.resources.external-apis.create',
        'namespace' => NULL,
        'prefix' => 'app/external-apis',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.external-apis.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/external-apis/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\ExternalApiResource\\Pages\\EditExternalApi@__invoke',
        'controller' => 'App\\Filament\\Resources\\ExternalApiResource\\Pages\\EditExternalApi',
        'as' => 'filament.resources.external-apis.edit',
        'namespace' => NULL,
        'prefix' => 'app/external-apis',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.real-estates.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/real-estates',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\RealEstateResource\\Pages\\ListRealEstates@__invoke',
        'controller' => 'App\\Filament\\Resources\\RealEstateResource\\Pages\\ListRealEstates',
        'as' => 'filament.resources.real-estates.index',
        'namespace' => NULL,
        'prefix' => 'app/real-estates',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.real-estates.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/real-estates/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\RealEstateResource\\Pages\\CreateRealEstate@__invoke',
        'controller' => 'App\\Filament\\Resources\\RealEstateResource\\Pages\\CreateRealEstate',
        'as' => 'filament.resources.real-estates.create',
        'namespace' => NULL,
        'prefix' => 'app/real-estates',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.real-estates.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/real-estates/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\RealEstateResource\\Pages\\EditRealEstate@__invoke',
        'controller' => 'App\\Filament\\Resources\\RealEstateResource\\Pages\\EditRealEstate',
        'as' => 'filament.resources.real-estates.edit',
        'namespace' => NULL,
        'prefix' => 'app/real-estates',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.tasklists.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/tasklists',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\TasklistResource\\Pages\\ListTasklists@__invoke',
        'controller' => 'App\\Filament\\Resources\\TasklistResource\\Pages\\ListTasklists',
        'as' => 'filament.resources.tasklists.index',
        'namespace' => NULL,
        'prefix' => 'app/tasklists',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.tasklists.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/tasklists/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\TasklistResource\\Pages\\CreateTasklist@__invoke',
        'controller' => 'App\\Filament\\Resources\\TasklistResource\\Pages\\CreateTasklist',
        'as' => 'filament.resources.tasklists.create',
        'namespace' => NULL,
        'prefix' => 'app/tasklists',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.tasklists.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/tasklists/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\TasklistResource\\Pages\\EditTasklist@__invoke',
        'controller' => 'App\\Filament\\Resources\\TasklistResource\\Pages\\EditTasklist',
        'as' => 'filament.resources.tasklists.edit',
        'namespace' => NULL,
        'prefix' => 'app/tasklists',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.users.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/users',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
        'as' => 'filament.resources.users.index',
        'namespace' => NULL,
        'prefix' => 'app/users',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.users.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/users/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
        'as' => 'filament.resources.users.create',
        'namespace' => NULL,
        'prefix' => 'app/users',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.users.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/users/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
        'as' => 'filament.resources.users.edit',
        'namespace' => NULL,
        'prefix' => 'app/users',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.user-roles.index' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/user-roles',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserRoleResource\\Pages\\ListUserRoles@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserRoleResource\\Pages\\ListUserRoles',
        'as' => 'filament.resources.user-roles.index',
        'namespace' => NULL,
        'prefix' => 'app/user-roles',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.user-roles.create' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/user-roles/create',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserRoleResource\\Pages\\CreateUserRole@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserRoleResource\\Pages\\CreateUserRole',
        'as' => 'filament.resources.user-roles.create',
        'namespace' => NULL,
        'prefix' => 'app/user-roles',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament.resources.user-roles.edit' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/user-roles/{record}/edit',
      'action' => 
      array (
        'domain' => NULL,
        'middleware' => 
        array (
          0 => 'Illuminate\\Cookie\\Middleware\\EncryptCookies',
          1 => 'Illuminate\\Cookie\\Middleware\\AddQueuedCookiesToResponse',
          2 => 'Illuminate\\Session\\Middleware\\StartSession',
          3 => 'Illuminate\\Session\\Middleware\\AuthenticateSession',
          4 => 'Illuminate\\View\\Middleware\\ShareErrorsFromSession',
          5 => 'Illuminate\\Foundation\\Http\\Middleware\\VerifyCsrfToken',
          6 => 'Illuminate\\Routing\\Middleware\\SubstituteBindings',
          7 => 'Filament\\Http\\Middleware\\DispatchServingFilamentEvent',
          8 => 'Filament\\Http\\Middleware\\MirrorConfigToSubpackages',
          9 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          10 => 'STS\\FilamentImpersonate\\Middleware\\ImpersonationBanner',
          11 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'App\\Filament\\Resources\\UserRoleResource\\Pages\\EditUserRole@__invoke',
        'controller' => 'App\\Filament\\Resources\\UserRoleResource\\Pages\\EditUserRole',
        'as' => 'filament.resources.user-roles.edit',
        'namespace' => NULL,
        'prefix' => 'app/user-roles',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::T3fReigw31kMsa7l' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'generated::T3fReigw31kMsa7l',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.message' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/message/{name}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\HttpConnectionHandler@__invoke',
        'controller' => 'Livewire\\Controllers\\HttpConnectionHandler',
        'as' => 'livewire.message',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.upload-file' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'livewire/upload-file',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'controller' => 'Livewire\\Controllers\\FileUploadHandler@handle',
        'as' => 'livewire.upload-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'livewire.preview-file' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/preview-file/{filename}',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'controller' => 'Livewire\\Controllers\\FilePreviewHandler@handle',
        'as' => 'livewire.preview-file',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aBKdxSGBA9JBlZaa' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@source',
        'as' => 'generated::aBKdxSGBA9JBlZaa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GkK0S8IINUs5Q8yX' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'livewire/livewire.js.map',
      'action' => 
      array (
        'uses' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'controller' => 'Livewire\\Controllers\\LivewireJavaScriptAssets@maps',
        'as' => 'generated::GkK0S8IINUs5Q8yX',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'filament-impersonate.leave' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'filament-impersonate/leave',
      'action' => 
      array (
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:268:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:53:"fn() => \\STS\\FilamentImpersonate\\Impersonate::leave()";s:5:"scope";s:34:"Illuminate\\Support\\ServiceProvider";s:4:"this";N;s:4:"self";s:32:"0000000000000b160000000000000000";}";s:4:"hash";s:44:"Zq97gP2BotbMjicTmXDjDPDVXRGnk1Rrh8162c7gAfU=";}}',
        'as' => 'filament-impersonate.leave',
        'middleware' => 
        array (
          0 => 'web',
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::awPjDdoy7AnysRXS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:295:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000b340000000000000000";}";s:4:"hash";s:44:"cMxFY9ognrCecuhm3qHHyQWnJygnJH43VCJrpX3i+Ew=";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::awPjDdoy7AnysRXS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oGJyWVyIUcKZvoEG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:263:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:45:"function () {
    return \\view(\'homepage\');
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000b360000000000000000";}";s:4:"hash";s:44:"R1X6ZtjeV+93yeWKl4soUIk5zs1YyeJXBCfQAtZlzR0=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::oGJyWVyIUcKZvoEG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rjqSMm7MoNuRSelQ' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'immo/{realEstate}/{slug}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:873:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:654:"function(\\App\\Models\\Openimmo\\RealEstate $realEstate) {
    if(!$realEstate->isActive()) {
        \\abort(\\Symfony\\Component\\HttpFoundation\\Response::HTTP_NOT_FOUND);
    }
    if($realEstate->getUrl()  != \\URL::current()) {
        return \\redirect($realEstate->getUrl());
    }

    $images = $realEstate->getImages()->map(function(\\App\\Models\\Openimmo\\Anhang $anhang) {
        return [
            "title" => $anhang->anhangtitel,
            "src" => $anhang->getUrl(),
            "gruppe" => $anhang->gruppe
        ];
    });

    return \\view("immo.realestate.detail", [
        "realEstate" => $realEstate,
        "images" => $images
    ]);
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000b380000000000000000";}";s:4:"hash";s:44:"xxVh0vM6z6BrfuAEKAFkGoSpeSUcBm9cvqhd0vsohJo=";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rjqSMm7MoNuRSelQ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'test.test.immo' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/test/immo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:259:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:41:"function(){
            \\dd(1);
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000b3e0000000000000000";}";s:4:"hash";s:44:"N/Q9j+OgXLxWJRvp1xwTaXn35f0sA1HklD5Ldb15yRE=";}}',
        'as' => 'test.test.immo',
        'namespace' => NULL,
        'prefix' => 'app/test',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'test.test.' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'app/test/wireui',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'Filament\\Http\\Middleware\\Authenticate',
        ),
        'uses' => 'O:47:"Laravel\\SerializableClosure\\SerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Signed":2:{s:12:"serializable";s:282:"O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:64:"function () {
            return \\view(\'test.wireui\');
        }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000b400000000000000000";}";s:4:"hash";s:44:"niYbzN/Reb4vIa4zUCHPU7RgCNpdioqIW4SvP8meDZE=";}}',
        'as' => 'test.test.',
        'namespace' => NULL,
        'prefix' => 'app/test',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
