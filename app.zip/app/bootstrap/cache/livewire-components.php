<?php return array (
  'immo-contact-form' => 'App\\Http\\Livewire\\ImmoContactForm',
);