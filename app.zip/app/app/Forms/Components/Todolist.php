<?php

namespace App\Forms\Components;

use Filament\Forms\Components\Field;

class Todolist extends Field
{
    protected string $view = 'forms.components.todolist';
}
