<?php

namespace App\Filament\Resources\CompanyOfficeResource\Pages;

use App\Filament\Resources\CompanyOfficeResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCompanyOffice extends CreateRecord
{
    protected static string $resource = CompanyOfficeResource::class;
}
