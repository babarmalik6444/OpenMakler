<?php

namespace App\Models;

use App\Models\Traits\HasNameTrait;

class UserPermission extends AbstractBaseModel
{
    use HasNameTrait;
}
